#!/usr/bin/env bash
set -euo pipefail
# Run this from the cloned GitHub repository. Build-only; no production writes.
if [[ -f project/package.json ]]; then
  cd project
elif [[ ! -f package.json || ! -f .openai/hosting.json ]]; then
  echo 'Run from the repository root or project/.' >&2
  exit 1
fi
node -e 'const n=Number(process.versions.node.split(".")[0]); if(n<24) { console.error("Node.js 24 or newer is required for this setup."); process.exit(1); }'
node -e 'const fs=require("node:fs"); const h=JSON.parse(fs.readFileSync(".openai/hosting.json","utf8")); if(h.project_id!=="appgprj_6aa7b6cb802c81918328655749df1975") throw Error("Unexpected Sites project");'
node build.mjs
node --check dist/server/index.js
node --input-type=module -e 'import {previewDatabase} from "./preview-db.mjs"; const db=previewDatabase(); db.close(); console.log("In-memory schema check passed");'
echo 'Cloud build setup verified. No production data or deployment was changed.'
